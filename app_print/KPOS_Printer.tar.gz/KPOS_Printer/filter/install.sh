#!/bin/sh
if [ $(getconf WORD_BIT) = '32' ] && [ $(getconf LONG_BIT) = '64' ] ; then
	cp ./64/rastertopos /usr/lib/cups/filter/
else
	cp ./32/rastertopos /usr/lib/cups/filter/
fi

chmod a+x /usr/lib/cups/filter/rastertopos
sync

